﻿namespace InterviewProject.Dtos
{
    public class CreateInterviewerDto
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string MiddleName { get; set; }
    }
}
