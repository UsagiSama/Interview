﻿namespace InterviewProject.Dtos
{
    public class UpdateInterviewerDto
        : CreateInterviewerDto
    {
        public int Id { get; set; }
    }
}
