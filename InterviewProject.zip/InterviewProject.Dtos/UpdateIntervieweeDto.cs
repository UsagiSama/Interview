﻿namespace InterviewProject.Dtos
{
    public class UpdateIntervieweeDto
        : CreateIntervieweeDto
    {
        public int Id { get; set; }
    }
}
