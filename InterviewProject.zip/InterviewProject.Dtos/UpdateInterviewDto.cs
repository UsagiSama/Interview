﻿namespace InterviewProject.Dtos
{
    public class UpdateInterviewDto
        : CreateInterviewDto
    {
        public int Id;
    }
}
