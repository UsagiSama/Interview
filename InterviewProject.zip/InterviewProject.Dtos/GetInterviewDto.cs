﻿namespace InterviewProject.Dtos
{
    public class GetInterviewDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Interviewer { get; set; }
        public string Interviewee { get; set; }
    }
}
