﻿namespace InterviewProject.Dtos
{
    public class CreateInterviewDto
    {
        public string Name { get; set; }
        public int IntervieweeId { get; set; }
        public int InterviewerId { get; set; }
    }
}
