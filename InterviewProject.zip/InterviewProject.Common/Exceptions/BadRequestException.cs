﻿using System;

namespace InterviewProject.Common.Exceptions
{
    public class BadRequestException
        : Exception
    {
    }
}
