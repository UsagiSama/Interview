﻿using System;

namespace InterviewProject.Common.Exceptions
{
    public class NotFoundException
        : Exception
    {
    }
}
