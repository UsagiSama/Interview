﻿using System;

namespace InterviewProject.Common.Exceptions
{
    public class UnauthorizedException
        : Exception
    {
    }
}
