﻿using System;

namespace InterviewProject.Common.Exceptions
{
    public class ForbiddenException
        : Exception
    {
    }
}
